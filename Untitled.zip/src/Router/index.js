import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import HomePage from '../Components/index';
import WwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5 from '../Components/wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5';
const RouterDOM = () => {
	return (
		<Router>
			<Switch>
				<Route exact path="/"><HomePage /></Route>
				<Route exact path="/wwwinterneepkbyhtmltodesignfreeversion16032024213900gmt5"><WwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5 /></Route>
			</Switch>
		</Router>
	);
}
export default RouterDOM;