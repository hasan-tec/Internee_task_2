import React from 'react'
import {Link} from 'react-router-dom'
export default function HomePage () {
    return (
	<div>
		<Link to='/wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5'><div>wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5</div></Link>
	</div>
	)
}