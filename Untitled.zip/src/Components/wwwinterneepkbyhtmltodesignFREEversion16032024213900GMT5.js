import React from 'react'
import './wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5.css'
import ImgAsset from '../public'
export default function WwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5 () {
	return (
		<div className='wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5'>
			<div className='Nav'>
				<div className='divcontainer'>
					<div className='Link'>
						<img className='_1stlogojpg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5__1stlogojpg} />
						<div className='divdflex'>
							<div className='Strong'>
								<span className='Interneepk'>Internee.pk</span>
							</div>
							<div className='Small'>
								<span className='VirtualInternshipPLATFORM'>Virtual Internship PLATFORM</span>
							</div>
						</div>
					</div>
					<div className='divnavbarNav'>
						<div className='ListItemLink'>
							<span className='Home'>Home</span>
						</div>
						<div className='ListItemLink_1'>
							<span className='About'>About</span>
						</div>
						<div className='ListItemLink_2'>
							<span className='Internships'>Internships</span>
						</div>
						<div className='ListItemLink_3'>
							<span className='Contact'>Contact</span>
						</div>
						<div className='ListItemLink_4'>
							<span className='LMS'>LMS</span>
							<span className='SuperscriptNew'>New</span>
						</div>
						<div className='ListItemLink_5'>
							<span className='JobPortal'>Job Portal</span>
							<span className='SuperscriptComingSoon'>Coming Soon</span>
						</div>
						<div className='ListItemLink_6'>
							<span className='InterneePortal'>Internee Portal</span>
						</div>
					</div>
				</div>
			</div>
			<img className='MainSection' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_MainSection} />
			<div className='MainSection_1'>
				<img className='founderjpg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_founderjpg} />
				<div className='divaboutinfo'>
					<span className='Heading4HammadSheikh'>Hammad Sheikh</span>
					<span className='Founder'>Founder</span>
				</div>
			</div>
			<div className='MainSection_2'>
				<span className='Heading2WelcometoInterneepk'>Welcome to Internee.pk</span>
				<span className='OurinternshipprogramisdesignedtogivestudentstheopportunitytoworkonmeaningfulprojectsandtaskswhilealsoreceivingmentorshipandguidancefromexperiencedprofessionalsinthefieldOurgoalistohelpinternsdeveloptheskillsandknowledgetheyneedtosucceedintheircareerswhilealsobuildingastrongnetworkoftalentedindividualswhomaybecomevaluablemembersofourteaminthefutureIfyourelookingforachallengingandrewardinginternshipexperienceweinviteyoutoexploreourprogramandApplyToday'>Our internship program is designed to give students the<br/>opportunity to work on meaningful projects and tasks, while also<br/>receiving mentorship and guidance from experienced<br/>professionals in the field. Our goal is to help interns develop the<br/>skills and knowledge they need to succeed in their careers, while<br/>also building a strong network of talented individuals who may<br/>become valuable members of our team in the future. If you're<br/>looking for a challenging and rewarding internship experience,<br/>we invite you to explore our program and Apply Today</span>
				<div className='Link_1'>
					<span className='Gettoknowus'>Get to know us</span>
				</div>
				<div className='Link_2'>
					<span className='ExploreInternships'>Explore Internships</span>
				</div>
			</div>
			<img className='MainSectionrayyanjpg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_MainSectionrayyanjpg} />
			<div className='MainSection_3'>
				<span className='Heading4RayyanZain'>Rayyan Zain</span>
				<span className='CMO'>CMO</span>
			</div>
			<span className='MainSectionHeading2Browseby'>Browse by Categories</span>
			<div className='MainSection_4'>
				<div className='Link_3'>
					<img className='Vector' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector} />
				</div>
				<span className='LinkSmallWebsiteDesigning'>Website Designing</span>
				<div className='Link_4'>
					<span className='_05'>05</span>
				</div>
			</div>
			<div className='MainSection_5'>
				<div className='Link_5'>
					<img className='Vector_1' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_1} />
				</div>
				<span className='LinkSmallWebDevelopment'>Web Development</span>
				<div className='Link_6'>
					<span className='_05_1'>05</span>
				</div>
			</div>
			<div className='MainSection_6'>
				<div className='Link_7'>
					<img className='Vector_2' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_2} />
				</div>
				<span className='LinkSmallCRMsChatbot'>CRM's & Chatbot<br/>Development</span>
				<div className='Link_8'>
					<span className='_04'>04</span>
				</div>
			</div>
			<div className='MainSection_7'>
				<div className='Link_9'>
					<img className='Vector_3' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_3} />
				</div>
				<span className='LinkSmallGraphicDesigning'>Graphic Designing &<br/>3D Modeling</span>
				<div className='Link_10'>
					<span className='_05_2'>05</span>
				</div>
			</div>
			<div className='MainSection_8'>
				<div className='Link_11'>
					<img className='Vector_4' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_4} />
				</div>
				<span className='LinkSmallMobileApplication'>Mobile Application<br/>Development</span>
				<div className='Link_12'>
					<span className='_06'>06</span>
				</div>
			</div>
			<div className='MainSection_9'>
				<span className='Heading2Launchingtechcareers'>Launching tech careers<br/>with internships, exposure,<br/>and networking.</span>
				<span className='Interneepkkickstartstudentstechcareerswithfirstinternshipsprovidingindustryexposurepracticalskillsandnetworkingopportunitiespavingthewayfortheirsuccessinthetechindustry'>Internee.pk kickstart student's tech careers with first internships,<br/>providing industry exposure, practical skills, and networking<br/>opportunities, paving the way for their success in the tech<br/>industry.</span>
				<span className='_5000'>5000+</span>
				<span className='Registeredusers'>Registered users</span>
				<span className='_35'>35+</span>
				<span className='OpeningInternships'>Opening Internships</span>
			</div>
			<img className='MainSectionpeopleworkingasteamcompanyjpg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_MainSectionpeopleworkingasteamcompanyjpg} />
			<div className='MainSection_10'>
				<span className='Heading2RecentInternships'>Recent Internships</span>
				<span className='StrongInternshipscameaftereverytwomonths'>Internships came after every two months Grab your internships on your<br/>favourite domain to boost up yourself in the field of Computer technology</span>
			</div>
			<div className='MainSection_11'>
				<span className='Heading4LinkDataAnalyst'>Data Analyst</span>
				<div className='Icon'>
					<img className='Vector_5' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_5} />
				</div>
				<span className='Remote'> Remote</span>
				<div className='Icon_1'>
					<img className='Vector_6' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_6} />
				</div>
				<span className='_1Month'> 1 Month</span>
				<div className='divdflex_1'>
					<div className='Link_13'>
						<span className='Applynow'>Apply now</span>
					</div>
				</div>
				<img className='Linkanalysisjpg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Linkanalysisjpg} />
			</div>
			<div className='MainSection_12'>
				<span className='Heading4LinkCyberSecurity'>Cyber Security</span>
				<div className='Icon_2'>
					<img className='Vector_7' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_7} />
				</div>
				<span className='Remote_1'> Remote</span>
				<div className='Icon_3'>
					<img className='Vector_8' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_8} />
				</div>
				<span className='_1Month_1'> 1 Month</span>
				<div className='divdflex_2'>
					<div className='Link_14'>
						<span className='Applynow_1'>Apply now</span>
					</div>
				</div>
				<img className='Linkhackjpeg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Linkhackjpeg} />
			</div>
			<div className='MainSection_13'>
				<span className='Heading4LinkCloudComputing'>Cloud Computing</span>
				<div className='Icon_4'>
					<img className='Vector_9' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_9} />
				</div>
				<span className='Remote_2'> Remote</span>
				<div className='Icon_5'>
					<img className='Vector_10' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_10} />
				</div>
				<span className='_1Month_2'> 1 Month</span>
				<div className='divdflex_3'>
					<div className='Link_15'>
						<span className='Applynow_2'>Apply now</span>
					</div>
				</div>
				<img className='Linkcloudjpg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Linkcloudjpg} />
			</div>
			<div className='MainSection_14'>
				<span className='Heading4LinkFrontendDevelopment'>Frontend Development</span>
				<div className='Icon_6'>
					<img className='Vector_11' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_11} />
				</div>
				<span className='Remote_3'> Remote</span>
				<div className='Icon_7'>
					<img className='Vector_12' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_12} />
				</div>
				<span className='_1Month_3'> 1 Month</span>
				<div className='divdflex_4'>
					<div className='Link_16'>
						<span className='Applynow_3'>Apply now</span>
					</div>
				</div>
				<img className='LinkFrontEndjpeg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_LinkFrontEndjpeg} />
			</div>
			<div className='MainSection_15'>
				<span className='Heading4LinkBackendDevelopment'>Backend Development</span>
				<div className='Icon_8'>
					<img className='Vector_13' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_13} />
				</div>
				<span className='Remote_4'> Remote</span>
				<div className='Icon_9'>
					<img className='Vector_14' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_14} />
				</div>
				<span className='_1Month_4'> 1 Month</span>
				<div className='divdflex_5'>
					<div className='Link_17'>
						<span className='Applynow_4'>Apply now</span>
					</div>
				</div>
				<img className='LinkBackendDevelopmentjpeg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_LinkBackendDevelopmentjpeg} />
			</div>
			<div className='MainSection_16'>
				<span className='Heading4LinkChatbotDevelopment'>Chatbot Development</span>
				<div className='Icon_10'>
					<img className='Vector_15' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_15} />
				</div>
				<span className='Remote_5'> Remote</span>
				<div className='Icon_11'>
					<img className='Vector_16' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_16} />
				</div>
				<span className='_1Month_5'> 1 Month</span>
				<div className='divdflex_6'>
					<div className='Link_18'>
						<span className='Applynow_5'>Apply now</span>
					</div>
				</div>
				<img className='LinkchatbotDevelopmentjpeg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_LinkchatbotDevelopmentjpeg} />
			</div>
			<div className='MainSection_17'>
				<span className='Heading4LinkMachineLearning'>Machine Learning</span>
				<div className='Icon_12'>
					<img className='Vector_17' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_17} />
				</div>
				<span className='Remote_6'> Remote</span>
				<div className='Icon_13'>
					<img className='Vector_18' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_18} />
				</div>
				<span className='_1Month_6'> 1 Month</span>
				<div className='divdflex_7'>
					<div className='Link_19'>
						<span className='Applynow_6'>Apply now</span>
					</div>
				</div>
				<img className='LinkMachine20Learningjpeg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_LinkMachine20Learningjpeg} />
			</div>
			<div className='MainSection_18'>
				<span className='Heading4LinkMobileAppDevelopment'>Mobile App Development</span>
				<div className='Icon_14'>
					<img className='Vector_19' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_19} />
				</div>
				<span className='Remote_7'> Remote</span>
				<div className='Icon_15'>
					<img className='Vector_20' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_20} />
				</div>
				<span className='_1Month_7'> 1 Month</span>
				<div className='divdflex_8'>
					<div className='Link_20'>
						<span className='Applynow_7'>Apply now</span>
					</div>
				</div>
				<img className='LinkMobile20App20Developerjpeg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_LinkMobile20App20Developerjpeg} />
			</div>
			<div className='MainSection_19'>
				<span className='Heading4LinkGraphicDesign'>Graphic Design</span>
				<div className='Icon_16'>
					<img className='Vector_21' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_21} />
				</div>
				<span className='Remote_8'> Remote</span>
				<div className='Icon_17'>
					<img className='Vector_22' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_22} />
				</div>
				<span className='_1Month_8'> 1 Month</span>
				<div className='divdflex_9'>
					<div className='Link_21'>
						<span className='Applynow_8'>Apply now</span>
					</div>
				</div>
				<img className='Linklogodesignerworkingcomputerdesktopjpg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Linklogodesignerworkingcomputerdesktopjpg} />
			</div>
			<div className='MainSectionLink'>
				<span className='BrowseInternship'>Browse Internship</span>
			</div>
			<div className='MainSection_20'>
				<div className='divcollg12'>
					<span className='Heading2HappyInterneeReviews'>Happy Internee Reviews</span>
					<div className='divowlstageouter'>
						<div className='divreviewsthumb'>
							<img className='obaidjfif' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_obaidjfif} />
							<span className='StrongObaidMuneer'>Obaid Muneer</span>
							<span className='SmallAIChatbotDeveloper'>AI & Chatbot Developer</span>
							<div className='Icon_18'>
								<img className='Vector_23' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_23} />
							</div>
							<div className='Icon_19'>
								<img className='Vector_24' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_24} />
							</div>
							<div className='Icon_20'>
								<img className='Vector_25' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_25} />
							</div>
							<div className='Icon_21'>
								<img className='Vector_26' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_26} />
							</div>
							<div className='Icon_22'>
								<img className='Vector_27' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_27} />
							</div>
							<span className='Heading5Thisinternshipgivesmechallangesthroughwhichit'>This internship gives me challanges through which it<br/>helps me grew myself in the field of Chatbot<br/>development</span>
							<img className='leftquotepng' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_leftquotepng} />
						</div>
						<div className='divreviewsthumb_1'>
							<img className='rasibjpg' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_rasibjpg} />
							<span className='StrongRasibAhmed'>Rasib Ahmed</span>
							<span className='SmallGraphicDesigner'>Graphic Designer</span>
							<div className='Icon_23'>
								<img className='Vector_28' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_28} />
							</div>
							<div className='Icon_24'>
								<img className='Vector_29' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_29} />
							</div>
							<div className='Icon_25'>
								<img className='Vector_30' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_30} />
							</div>
							<div className='Icon_26'>
								<img className='Vector_31' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_31} />
							</div>
							<div className='Icon_27'>
								<img className='Vector_32' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_32} />
							</div>
							<span className='Heading5Thisinternshipoppurtunityboostmypens'>This internship oppurtunity boost my pen's<br/>productivity and helps me to increase the design<br/>knowladge and branding</span>
							<img className='leftquotepng_1' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_leftquotepng} />
						</div>
					</div>
				</div>
			</div><div className='MainSection_21' style={{backgroundImage: `url(${ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_MainSection_21}),linear-gradient(0deg, rgba(40,78,58,1.00), rgba(40,78,58,1.00))`}}/>
			<div className='Footer'>
				<img className='_1stlogojpg_1' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5__1stlogojpg} />
				<span className='StrongInternee'>Internee.pk</span>
				<span className='SmallVirtualInternshipPLATFORM'>Virtual Internship PLATFORM</span>
				<div className='Icon_28'>
					<img className='Vector_33' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_33} />
				</div>
				<span className='Linkwwwinterneepk'>www.internee.pk</span>
				<div className='Icon_29'>
					<img className='Vector_34' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_34} />
				</div>
				<span className='Link923453191638'>+92 345 3191638</span>
				<span className='Link923492861021'>      +92 349 2861021</span>
				<div className='Icon_30'>
					<img className='Vector_35' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_35} />
				</div>
				<span className='Linkinfointerneepk'>info@internee.pk</span>
			</div>
			<div className='Footer_1'>
				<span className='Heading6Company'>Company</span>
				<span className='ListItemLinkHome'>Home</span>
				<span className='ListItemLinkAbout'>About</span>
				<span className='ListItemLinkInternships'>Internships</span>
				<span className='ListItemLinkContact'>Contact</span>
			</div>
			<div className='Footer_2'>
				<span className='Heading6Resources'>Resources</span>
				<span className='ListItemLinkDiscordServer'>Discord Server</span>
				<span className='ListItemLinkBlog'>Blog</span>
				<span className='ListItemLinkPodcast'>Podcast</span>
			</div>
			<div className='FooterForm'>
				<span className='Heading6GetUpdatesAboutInternships'>Get Updates About Internships</span>
				<div className='divinputgroup'>
					<div className='spanbasicaddon1'>
						<div className='before'>
							<div className='Icon_31'>
								<img className='Vector_36' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_36} />
							</div>
						</div>
					</div>
				</div>
			</div>
			<div className='Footer_3'>
				<div className='divcollg4'>
					<span className='CopyrightInterneepk2024'>Copyright © Internee.pk 2024</span>
					<div className='List'>
						<div className='Item'>
							<span className='LinkPrivacyPolicy'>Privacy Policy</span>
						</div>
						<div className='Item_1'>
							<span className='LinkTerms'>Terms</span>
						</div>
					</div>
				</div>
				<div className='ListItemLink_7'>
					<div className='Icon_32'>
						<img className='Vector_37' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_37} />
					</div>
				</div>
				<div className='ListItemLink_8'>
					<div className='Icon_33'>
						<img className='Vector_38' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_38} />
					</div>
				</div>
				<div className='ListItemLink_9'>
					<div className='Icon_34'>
						<img className='Vector_39' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_39} />
					</div>
				</div>
				<div className='ListItemLink_10'>
					<div className='Icon_35'>
						<img className='Vector_40' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_40} />
					</div>
				</div>
				<div className='ListItemLink_11'>
					<div className='Icon_36'>
						<img className='Vector_41' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_41} />
					</div>
				</div>
				<span className='PoweredByTechvioChats'>Powered By: Techvio Chats</span>
				<div className='Link_22'>
					<div className='Icon_37'>
						<img className='Vector_42' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_42} />
					</div>
				</div>
			</div>
			<div className='divchatwrapper'>
				<div className='dfmessagelist'>
					<div className='divmessageList'>
						<div className='divmessage'>
							<span className='HellotechchampIamvirtualassistantofInterneepkTellmehowcanIhelpyou'>Hello tech champ😉! I am virtual assistant of<br/>Internee.pk 🤖👨‍💻. Tell me how can I help you?</span>
						</div>
					</div>
					<div className='divdismissIcon'>
						<div className='SVG'>
							<img className='Vector_43' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_43} />
							<img className='Vector_44' src = {ImgAsset.wwwinterneepkbyhtmltodesignFREEversion16032024213900GMT5_Vector_44} />
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}